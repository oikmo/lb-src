				<div id="Footer" style="display: flow-root;margin:auto;">
					<hr>
					<p class="Legalese">
						LAMBDABLOX, made and owned by <a href="https://youtube.com/@oikmo">Oikmo</a>, characters, logos, names, and all related indicia are trademarks of <a href="https://web.archive.org/web/20090604133254/http://www.roblox.com/info/About.aspx">DewdBlox Corporation</a>, ©2024. 
						<br>
						LAMBDABLOX is not sponsored, authorized or endorsed by any producer of plastic building bricks, NOR ROBLOX THEMSELVES including The LEGO Group, MEGA Brands, and K'Nex,<br> and no resemblance to the products of these companies is intended.<br>Use of this site signifies your acceptance of the <a id="ctl00_rbxFooter_hlTermsOfService" href="https://web.archive.org/web/20090604133254/http://www.roblox.com/info/TermsOfService.aspx">Terms and Conditions</a>.
						<br>
					</p>
				</div>
			</div>
		</form>
	</body>
</html>