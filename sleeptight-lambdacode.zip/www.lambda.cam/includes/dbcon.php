<?php 
	$con = mysqli_connect("localhost", "rurt", 'erm what the sigma', "lambda-afs");
?>