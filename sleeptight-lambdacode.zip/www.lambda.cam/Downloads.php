<?php
	include('includes/header.php');
?>

<div id="Body" style="text-align: center; margin: 10px auto 150px auto; width: 855px; border: black thin solid; padding: 22px; background-color: white;">
	<div id="RobloxAtAGlance">
		<ul id="ThingsToDo">
			<li id="Point1">
				<h3>Build your personal Place</h3>
				<div>Create buildings, vehicles, scenery, and traps with thousands of virtual bricks.</div>
			</li>
			<li id="Point2">
				<h3>Meet new friends online</h3>
				<div>Visit your friend's place, chat in 3D, and build together.</div>
			</li>
			<li id="Point3">
				<h3>Battle in the Brick Arenas</h3>
				<div>Play with the slingshot, rocket, or other brick battle tools.  Be careful not to get "bloxxed".</div>
			</li>
		</ul>
		<div id="Showcase">
		<div id="ctl00_cphRoblox_RobloxAtAGlanceLoginView_RobloxAtAGlance_Anonymous_OldPlayer">
		<b>video here...</b>
		</div> 
		</div>
		<div id="Install">
		<div id="CompatibilityNote">Works with your<br>Windows PC!</div>
		<div id="DownloadAndPlay">
			<a id="ctl00_cphRoblox_RobloxAtAGlanceLoginView_RobloxAtAGlance_Anonymous_hlDownloadAndPlay" href="download/LambdaBlox-Setup.exe">
				<img src="/images/DownloadAndPlay.png" alt="FREE - Download and Play!" border="0">
			</a>
		</div>
	</div>
	</div>
	
	
		
	<div id="ctl00_cphRoblox_ie6_peekaboo" style="clear: both"></div>
</div>
<?php
	include('includes/footer.php');
?>