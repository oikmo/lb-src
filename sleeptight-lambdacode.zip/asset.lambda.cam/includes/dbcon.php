<?php 
	$con = mysqli_connect("localhost", "afsroot", 'DONT$THINKthrice321', "lambda-afs");
?>
